<footer>
    <div class="icon">
        <a href="index.php">
        <img class="logo64"src="assets\logo\logo64h.svg" alt="logo do site">
        </a>
    </div>
    <ul>
        <li><a href="sobre.php">Sobre</a></li>
        <li><a href="fale-conosco.php">Fale Conosco</a></li>
        <li><a href="termos-de-uso.php">Termos de uso</a></li>
    </ul>
</footer>